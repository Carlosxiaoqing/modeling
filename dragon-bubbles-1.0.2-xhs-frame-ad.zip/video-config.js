/* Local promotional clip: 300 frames in 75 WebP atlases plus 14 sound-data scripts. */
window.CANDY_PROMO = {
    width: 360,
    height: 640,
    fps: 10,
    frames: 300,
    framesPerAtlas: 4,
    atlasColumns: 2,
    atlasCount: 75,
    atlasPrefix: './assets/promo/frames/atlas-',
    audioPrefix: './assets/promo/audio/part-',
    audioParts: 14,
    minimumSeconds: 30
};

(function () {
    'use strict';

    window.CandyPromoAudioParts = [];
    var installed = false;
    var active = false;
    var ownerScript = document.currentScript;
    if (!ownerScript || !/video-config\.js(?:[?#]|$)/.test(ownerScript.src || '')) {
        var scripts = document.getElementsByTagName('script');
        for (var scriptIndex = 0; scriptIndex < scripts.length; scriptIndex++) {
            if (/video-config\.js(?:[?#]|$)/.test(scripts[scriptIndex].src)) ownerScript = scripts[scriptIndex];
        }
    }
    var packageBase = ownerScript && ownerScript.src;
    function packagePath(path) {
        try { return new URL(path, packageBase || document.baseURI || window.location.href).href; }
        catch (ignore) { return path; }
    }

    function pad(value, length) {
        return ('000' + value).slice(-length);
    }

    window.CandyPromoPlayer = {
        install: function () {
            if (installed) return;
            installed = true;
            var config = window.CANDY_PROMO;
            var dialog = document.getElementById('promo-dialog');
            var oldVideo = document.getElementById('promo-video');
            var status = document.getElementById('promo-status');
            var skip = document.getElementById('skip-promo');
            if (!dialog || !oldVideo || !status || !skip || !window.CandyAds) return;

            var stage = document.createElement('div');
            stage.style.cssText = 'position:relative;width:100%;background:#193e39;';
            var canvas = document.createElement('canvas');
            canvas.id = 'promo-canvas';
            canvas.width = config.width;
            canvas.height = config.height;
            canvas.setAttribute('aria-label', '30秒推广内容');
            canvas.style.cssText = 'display:block;width:100%;height:auto;image-rendering:auto;touch-action:manipulation;';
            stage.appendChild(canvas);
            oldVideo.parentNode.replaceChild(stage, oldVideo);
            var controls = document.createElement('div');
            controls.style.cssText = 'display:flex;justify-content:center;flex-wrap:wrap;';
            var toggle = document.createElement('button');
            toggle.id = 'promo-toggle';
            toggle.type = 'button';
            toggle.style.cssText = 'margin:4px;padding:10px 14px;font-size:13px;';
            var sound = document.createElement('button');
            sound.id = 'promo-sound';
            sound.type = 'button';
            sound.style.cssText = 'margin:4px;padding:10px 14px;font-size:13px;';
            controls.appendChild(toggle);
            controls.appendChild(sound);
            status.parentNode.insertBefore(controls, skip);
            skip.style.marginTop = '8px';
            dialog.style.cssText = 'width:90vw;max-width:390px;max-height:90vh;overflow:auto;padding:16px;';
            var context2d = canvas.getContext('2d');
            if (!context2d) return;

            window.CandyAds.register({
                showRewardedVideo: function () {
                    if (active) return Promise.resolve({ completed: false, reason: '推广内容正在播放' });
                    active = true;
                    return new Promise(function (resolve) {
                        var scene = window.candyGame.scene.getScene('Adventure');
                        var duration = config.frames / config.fps * 1000;
                        var position = 0;
                        var mode = 'loading';
                        var wanted = true;
                        var closed = false;
                        var initialized = false;
                        var lastTime = 0;
                        var request = 0;
                        var shownFrame = -1;
                        var blockedAtlas = null;
                        var images = new Map();
                        var scriptLoads = [];
                        var audioContext = null;
                        var audioBuffer = null;
                        var audioSource = null;
                        var audioGain = null;
                        var audioGeneration = 0;
                        var muted = !!(window.CandyAudio && !window.CandyAudio.settings.enabled);
                        var audioUnavailable = false;

                        scene.setPausedByUI(true);
                        canvas.setAttribute('data-state', mode);
                        canvas.setAttribute('data-watched-ms', '0');
                        canvas.setAttribute('data-frame', '-1');
                        canvas.setAttribute('data-resource-base', packageBase || '');
                        context2d.fillStyle = '#193e39';
                        context2d.fillRect(0, 0, config.width, config.height);

                        function showState(nextMode, message) {
                            mode = nextMode;
                            canvas.setAttribute('data-state', mode);
                            canvas.setAttribute('data-watched-ms', String(Math.floor(position)));
                            var progress = '已观看 ' + Math.floor(position / 1000) + ' / 30 秒';
                            status.textContent = progress + ' · ' + (message || '完整播放后开启隐藏关');
                            toggle.disabled = mode === 'loading';
                            toggle.textContent = mode === 'playing' || mode === 'buffering' ? '暂停播放' : mode === 'error' ? '重试加载' : '继续播放';
                            sound.disabled = audioUnavailable;
                            sound.textContent = audioUnavailable ? '声音不可用' : muted ? '声音：关' : '声音：开';
                        }

                        function stopSound() {
                            audioGeneration++;
                            if (audioSource) {
                                try { audioSource.stop(); } catch (ignore) {}
                                try { audioSource.disconnect(); } catch (ignore) {}
                                audioSource = null;
                            }
                        }

                        function startSound() {
                            stopSound();
                            if (!audioContext || !audioBuffer || audioContext.state !== 'running' || closed) return;
                            try {
                                audioSource = audioContext.createBufferSource();
                                audioSource.buffer = audioBuffer;
                                audioSource.connect(audioGain);
                                audioSource.start(0, Math.min(position / 1000, Math.max(0, audioBuffer.duration - 0.01)));
                            } catch (error) {
                                stopSound();
                                audioUnavailable = true;
                            }
                        }

                        function resumeSound() {
                            if (!audioContext || audioContext.state === 'running') return;
                            var generation = audioGeneration;
                            try {
                                var result = audioContext.resume();
                                if (result && typeof result.then === 'function') {
                                    result.then(function () {
                                        if (!closed && mode === 'playing' && generation === audioGeneration) startSound();
                                    }, function () {});
                                }
                            } catch (ignore) {}
                        }

                        function pause(message) {
                            wanted = false;
                            stopSound();
                            lastTime = 0;
                            if (request) cancelAnimationFrame(request);
                            request = 0;
                            if (!closed) showState(initialized ? 'paused' : 'loading', message || '已暂停，暂停期间不计时');
                        }

                        function loadImage(index, retry) {
                            if (images.has(index)) {
                                var existing = images.get(index);
                                if (!retry || existing.state !== 'error') return existing.promise;
                                existing.dispose();
                                images.delete(index);
                            }
                            var entry = { state: 'loading', image: new Image(), dispose: function () {} };
                            var timer;
                            entry.promise = new Promise(function (accept, reject) {
                                var settled = false;
                                function finish(error) {
                                    if (settled) return;
                                    settled = true;
                                    clearTimeout(timer);
                                    entry.image.onload = entry.image.onerror = null;
                                    if (error) {
                                        entry.state = 'error';
                                        reject(error);
                                    } else {
                                        entry.state = 'ready';
                                        accept(entry.image);
                                    }
                                }
                                entry.dispose = function () {
                                    finish(new Error('播放已结束'));
                                    entry.image.removeAttribute('src');
                                };
                                entry.image.onload = function () {
                                    if (entry.image.naturalWidth !== config.width * config.atlasColumns ||
                                        entry.image.naturalHeight !== config.height * 2) {
                                        finish(new Error('推广画面尺寸不正确'));
                                    } else finish(null);
                                };
                                entry.image.onerror = function () { finish(new Error('推广画面加载失败')); };
                                timer = setTimeout(function () { finish(new Error('推广画面加载超时')); }, 12000);
                                entry.image.src = packagePath(config.atlasPrefix + pad(index, 3) + '.webp');
                            });
                            images.set(index, entry);
                            entry.promise.catch(function () {});
                            return entry.promise;
                        }

                        function prefetch(index) {
                            var remove = [];
                            images.forEach(function (entry, key) {
                                if (key < index - 1 || key > index + 1) remove.push(key);
                            });
                            remove.forEach(function (key) { images.get(key).dispose(); images.delete(key); });
                            if (index + 1 < config.atlasCount) loadImage(index + 1, false).catch(function () {});
                        }

                        function draw(frame) {
                            var atlas = Math.floor(frame / config.framesPerAtlas);
                            var entry = images.get(atlas);
                            if (!entry || entry.state !== 'ready') return false;
                            if (frame !== shownFrame) {
                                var local = frame % config.framesPerAtlas;
                                context2d.drawImage(entry.image,
                                    local % config.atlasColumns * config.width,
                                    Math.floor(local / config.atlasColumns) * config.height,
                                    config.width, config.height, 0, 0, config.width, config.height);
                                shownFrame = frame;
                                canvas.setAttribute('data-frame', String(frame));
                            }
                            prefetch(atlas);
                            return true;
                        }

                        function loadSoundPart(index) {
                            if (window.CandyPromoAudioParts[index]) return Promise.resolve();
                            return new Promise(function (accept, reject) {
                                var script = document.createElement('script');
                                var timer;
                                var settled = false;
                                function finish(error) {
                                    if (settled) return;
                                    settled = true;
                                    clearTimeout(timer);
                                    script.onload = script.onerror = null;
                                    if (script.parentNode) script.parentNode.removeChild(script);
                                    if (error) reject(error); else accept();
                                }
                                scriptLoads.push(function () { finish(new Error('播放已结束')); });
                                script.src = packagePath(config.audioPrefix + pad(index, 2) + '.js');
                                script.onload = function () {
                                    finish(window.CandyPromoAudioParts[index] ? null : new Error('声音数据缺失'));
                                };
                                script.onerror = function () { finish(new Error('声音加载失败')); };
                                timer = setTimeout(function () { finish(new Error('声音加载超时')); }, 12000);
                                document.head.appendChild(script);
                            });
                        }

                        function loadSound() {
                            if (!audioContext) return Promise.resolve();
                            var nextPart = 0;
                            function worker() {
                                if (closed || nextPart >= config.audioParts) return Promise.resolve();
                                var part = nextPart++;
                                return loadSoundPart(part).then(worker);
                            }
                            return Promise.all([worker(), worker(), worker()]).then(function () {
                                if (closed) return;
                                var chunks = [];
                                var length = 0;
                                for (var i = 0; i < config.audioParts; i++) {
                                    var chunk = atob(window.CandyPromoAudioParts[i]);
                                    chunks.push(chunk);
                                    length += chunk.length;
                                }
                                var bytes = new Uint8Array(length);
                                var offset = 0;
                                chunks.forEach(function (chunk) {
                                    for (var j = 0; j < chunk.length; j++) bytes[offset++] = chunk.charCodeAt(j);
                                });
                                return new Promise(function (accept, reject) {
                                    var result = audioContext.decodeAudioData(bytes.buffer, accept, reject);
                                    if (result && typeof result.then === 'function') result.then(accept, reject);
                                });
                            }).then(function (buffer) {
                                if (!closed && buffer) audioBuffer = buffer;
                            });
                        }

                        function cleanup(completed, reason) {
                            if (closed) return;
                            closed = true;
                            active = false;
                            wanted = false;
                            if (request) cancelAnimationFrame(request);
                            stopSound();
                            scriptLoads.forEach(function (cancel) { cancel(); });
                            images.forEach(function (entry) { entry.dispose(); });
                            images.clear();
                            audioBuffer = null;
                            if (audioContext) {
                                audioContext.onstatechange = null;
                                try {
                                    var closing = audioContext.close();
                                    if (closing && typeof closing.catch === 'function') closing.catch(function () {});
                                } catch (ignore) {}
                            }
                            document.removeEventListener('visibilitychange', visibility);
                            window.removeEventListener('blur', blur);
                            window.removeEventListener('pagehide', pagehide);
                            dialog.removeEventListener('close', cancelled);
                            dialog.removeEventListener('cancel', cancelled);
                            toggle.onclick = sound.onclick = skip.onclick = null;
                            canvas.setAttribute('data-state', completed ? 'completed' : 'closed');
                            if (dialog.open) dialog.close();
                            scene.setPausedByUI(false);
                            resolve({ completed: completed, reason: reason });
                        }

                        function cancelled() { cleanup(false, '已跳过推广内容，可继续主线'); }
                        function visibility() { if (document.hidden) pause('已切到后台，返回后点击继续播放'); }
                        function blur() { pause('已离开当前窗口，返回后点击继续播放'); }
                        function pagehide() { cleanup(false, '播放已中断，可重新观看'); }

                        function waitForAtlas(index, retry) {
                            blockedAtlas = index;
                            stopSound();
                            lastTime = 0;
                            showState('buffering', '正在加载画面，等待期间不计时');
                            loadImage(index, retry).then(function () {
                                if (closed) return;
                                blockedAtlas = null;
                                if (wanted && !document.hidden) play();
                                else showState('paused', '已暂停，点击继续播放');
                            }, function () {
                                if (!closed) showState('error', '画面加载失败，点击重试；尚未解锁');
                            });
                        }

                        function tick(now) {
                            request = 0;
                            if (closed || mode !== 'playing') return;
                            if (document.hidden) { visibility(); return; }
                            var delta = lastTime ? now - lastTime : 0;
                            lastTime = now;
                            if (delta < 0 || delta > 250) {
                                startSound();
                                request = requestAnimationFrame(tick);
                                return;
                            }
                            var next = Math.min(duration, position + delta);
                            var frame = Math.min(config.frames - 1, Math.floor(next * config.fps / 1000));
                            try {
                                if (!draw(frame)) {
                                    waitForAtlas(Math.floor(frame / config.framesPerAtlas), false);
                                    return;
                                }
                            } catch (error) {
                                stopSound();
                                showState('error', '画面无法播放，点击重试；尚未解锁');
                                return;
                            }
                            position = next;
                            showState('playing', audioUnavailable ? '声音暂不可用，画面正常播放' : '完整播放后开启隐藏关');
                            if (position >= duration && position >= config.minimumSeconds * 1000) {
                                cleanup(true, '已完整观看30秒');
                                return;
                            }
                            request = requestAnimationFrame(tick);
                        }

                        function play() {
                            if (closed || !initialized || document.hidden) return;
                            wanted = true;
                            var frame = Math.min(config.frames - 1, Math.floor(position * config.fps / 1000));
                            if (!draw(frame)) { waitForAtlas(Math.floor(frame / config.framesPerAtlas), true); return; }
                            showState('playing');
                            lastTime = 0;
                            startSound();
                            resumeSound();
                            if (!request) request = requestAnimationFrame(tick);
                        }

                        toggle.onclick = function () {
                            if (mode === 'playing' || mode === 'buffering') pause();
                            else if (mode === 'error' && !initialized) initialize();
                            else if (mode === 'error' && blockedAtlas !== null) { wanted = true; waitForAtlas(blockedAtlas, true); }
                            else play();
                        };
                        sound.onclick = function () {
                            muted = !muted;
                            if (audioGain) audioGain.gain.value = muted ? 0 : 0.85;
                            if (!muted) resumeSound();
                            showState(mode);
                        };
                        skip.onclick = cancelled;
                        document.addEventListener('visibilitychange', visibility);
                        window.addEventListener('blur', blur);
                        window.addEventListener('pagehide', pagehide);
                        dialog.addEventListener('close', cancelled);
                        dialog.addEventListener('cancel', cancelled);

                        try {
                            var Audio = window.AudioContext || window.webkitAudioContext;
                            if (Audio) {
                                audioContext = new Audio();
                                audioGain = audioContext.createGain();
                                audioGain.gain.value = muted ? 0 : 0.85;
                                audioGain.connect(audioContext.destination);
                                resumeSound();
                                audioContext.onstatechange = function () {
                                    if (!closed && initialized && mode === 'playing' && audioContext.state !== 'running' && !muted) {
                                        pause('声音播放已暂停，点击继续播放');
                                    }
                                };
                            } else audioUnavailable = true;
                        } catch (error) { audioUnavailable = true; audioContext = null; }

                        function initialize() {
                            wanted = true;
                            showState('loading', '正在准备推广内容，加载期间不计时');
                            var audioReady = loadSound().catch(function () { audioUnavailable = true; });
                            Promise.all([loadImage(0, true), audioReady]).then(function () {
                                if (closed) return;
                                initialized = true;
                                draw(0);
                                if (wanted && !document.hidden) play();
                                else showState('paused', '已暂停，点击继续播放');
                            }, function () {
                                if (!closed) showState('error', '画面加载失败，点击重试；尚未解锁');
                            });
                        }

                        try { dialog.showModal(); }
                        catch (error) { cleanup(false, '当前环境无法打开推广内容'); return; }
                        initialize();
                    });
                }
            });
        }
    };
}());
